/**
 * @author pdhindsa
 */
$.paramquery.pqGrid.regional['ja'] = {
    strLoading: "積載",
    strAdd: "",
    strEdit: "",
    strDelete: "",
    strSearch: "",
    strNothingFound: "",
    strSelectedmatches:"",
    strPrevResult: "",
    strNextResult: "",
    strNoRows: "表示するには行ません."
};
$.paramquery.pqPager.regional['ja']={
    strPage:"{1} の {0} ページ",
    strFirstPage:"最初",
    strPrevPage:"前",
    strNextPage:"次",
    strLastPage:"最後",
    strRefresh:"リフレッシュ",	
    strRpp:"ページあたりのレコード: {0}",
    strDisplay:"表示 {0} から {1} {2} 項目の"	
};
